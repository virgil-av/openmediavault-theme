OMV.WorkspaceManager.registerNode({
    id: 'theme',
    path: '/system',
    text: 'Theme Changer',
    icon16: 'images/theme.png',
    iconSvg: 'images/theme.svg'
});