OpenMediaVault plugin to switch themes

